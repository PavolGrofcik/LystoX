#! /usr/bin/bash

echo -e "Script name is: $(basename $0)\n"

if [ $# -lt 1 ]; then
echo "Missing parameter [pathname] to .h5 data"
exit 2
else
pathname=$1
echo "Path to data.h5: $pathname"

if [ -f $pathname ]; then

a="7273788230d17ba1a6b809f99c92c2ba"
b=$( md5sum.exe $pathname | tr -s " " | cut -f 1 -d " ")

echo "Base hash: $a"
echo "Calculated: $b"

if [ $a = $b ]; then
	echo 'Hash matched!'
else
	echo 'Not matched!!'
fi
else
	echo "$1 is not file"
fi
fi
