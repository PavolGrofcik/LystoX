"""
Logger class to define configuration
"""

import yaml
import logging.config

FILE_LOG_CONFIG = './resources/configs/config.yaml'


def setup_logger():
    """
    Method initializes logger for an application.

    :return: None
    """

    with open(FILE_LOG_CONFIG, 'r') as f:
        cfg = yaml.full_load(f.read())
        logging.config.dictConfig(cfg['logging'])
