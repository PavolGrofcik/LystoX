"""
Main file to start the application
"""

import sys
from PyQt5 import QtWidgets
from view.view import Window
from logger.logger import setup_logger


if __name__ == '__main__':
    setup_logger()
    app = QtWidgets.QApplication(sys.argv)
    Window = Window()
    app.exit(app.exec_())
