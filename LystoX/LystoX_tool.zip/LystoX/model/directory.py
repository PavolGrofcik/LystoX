"""
Model class to represent Directory
"""

import os
import logging
from model.image import Image

DIR_DST_FINAL = 'data_annotated'
DIR_DST_UNMATCHED = 'Unmatched'
DIR_DST_ORIGINAL = 'Original'
LOGGER_NAME = 'app_logger.'

logger = logging.getLogger(LOGGER_NAME + __name__)


class Directory:
    def __init__(self, path, dst=None, labels=None):
        self.index = self.index_len = self.last = None
        self.path = os.path.abspath(path)
        self.set_destination_directory(dst)
        self.img_names = None
        self.meta = None
        self.labels = labels
        self.load_images()
        self.init_iterator()
        logger.info('Directory initialization successful!')

    def init_iterator(self):
        self.index_len = len(self.img_names)
        if self.index_len == 0:
            self.index = None
            self.last = None
        else:
            self.index = 0
            self.last = self.index_len - 1
        logger.debug(f'Index length: {self.index_len}, actual index: {self.index}'
                     f' ,last index: {self.last}')
        logger.info('Dir iterator initialization successful!')

    def check_index(self, prev=False):
        if self.index_len != 0:
            if self.last >= self.index >= 0:
                return True
        return False

    def set_index(self):
        if self.index < self.last:
            self.index += 1
            return
        if self.index == self.last:
            self.index = 0

    def iter_next(self):
        if self.check_index():
            self.set_index()
            logger.debug(f'Iterator index: {self.index}')
            return Image(self.img_names[self.index])

    def iter_prev(self):
        if self.check_index():
            if self.index == 0:
                self.index = self.last
            else:
                self.index -= 1
            logger.debug(f'Iterator index: {self.index}')
            return Image(self.img_names[self.index])

    def iter_act(self):
        if self.check_index():
            return Image(self.img_names[self.index])

    def get_dst_name(self):
        """Method returns destination directory
        in a more readable way for view"""

        if len(self.dst) > 50:
            name = '\\'.join(self.dst.split('\\')[:2]) + ' ... ' + '\\'.join(self.dst.split('\\')[-3:])
            logger.debug(f'Destination directory name: {name}')
            return name
        else:
            return self.dst

    def get_src_name(self):
        """Method returns source directory
         in a more readable way for view"""

        if len(self.path) > 50:
            name = '\\'.join(self.path.split('\\')[:2]) + ' ... ' + '\\'.join(self.path.split('\\')[-3:])
            logger.debug(f'Source directory name: {name}')
            return name
        else:
            return self.path

    def set_destination_directory(self, dst):
        """
        Method sets the dst as destination directory.
        Be careful!! Name 'dst' supports only ASCII
        characters.

        :param dst: Destination to be saved
        :return: None
        """

        logger.debug(f'Destination loaded directory: {dst}')
        if dst is None:
            self.make_dst_directories()
        else:
            try:
                self.make_dst_directories(dst)
            except:
                self.make_dst_directories()

    def make_dst_directories(self, dst=None):
        """
        Method creates new destination directories if not exists

        :param dst: Destination path
        :return: None
        """

        if dst is None:
            self.dst = self.path + '\\' + DIR_DST_FINAL
        else:
            self.dst = dst + '\\' + DIR_DST_FINAL
        self.dst_diff = self.dst + '\\' + DIR_DST_UNMATCHED
        self.dst_origin = self.dst + '\\' + DIR_DST_ORIGINAL
        logger.debug(f'Destination dir: {self.dst}'
                     f' Unmatched dir: {self.dst_diff}'
                     f' Original dir: {self.dst_origin}')

        if not os.path.exists(self.dst):
            os.makedirs(self.dst)
            os.makedirs(self.dst_diff)
            os.makedirs(self.dst_origin)
        if not os.path.exists(self.dst_diff):
            os.makedirs(self.dst_diff)
        if not os.path.exists(self.dst_origin):
            os.makedirs(self.dst_origin)

    def is_empty(self):
        if self.index_len is None or self.index_len == 0:
            return True
        return False

    def load_images(self):
        img_names = os.listdir(self.path)
        self.img_names = []
        if img_names is not None:
            for image in img_names:
                format = ("." + image.split('.')[-1])
                if format in Image.formats:
                    self.img_names.append(os.path.abspath(self.path + '\\' + image))
                if format in Image.metadata:
                    if image == "labels.csv" or (self.labels is not None
                                                 and image == self.labels):
                        self.meta = os.path.abspath(self.path + '\\' + image)
            logger.debug(f'Image metadata file: {self.meta}')
            logger.info(f'Images loaded successfully!')

    def img_from_images(self, name=None):
        logger.debug(f'Image name to be loaded: {name}')
        if name is not None:
            if name in self.img_names:
                return Image(name)

    def img_from_index(self, index=None):
        logger.debug(f'Index of image: {index}')
        if index and self.index_len != 0:
            if self.index_len >= index >= 1:
                self.index = index - 1
                return Image(self.img_names[self.index])

    def get_metadata(self):
        if self.meta is not None:
            return self.meta

    def get_imgs_len(self):
        return str(1 + self.last)

    def get_img_seq(self, img_name):
        return str(1 + self.index)


if __name__ == '__main__':
    dir = Directory(path=r'C:\Users\grofc\Desktop\Lympho BC\Data Augmentation\Images')
    dir.set_destination_directory('.')
    print("Dst is {}".format(dir.dst))
