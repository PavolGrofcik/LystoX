"""
Model class to represent an Image
"""

import cv2
import copy as cp
import numpy as np
import logging

BLACK_VALUE = 0
GREY_VALUE = 90
WHITE_VALUE = 255
THRESHOLD_VALUE = 33
NEIGHBOURS_VALUE = 41
ELEMENT_VALUE = 11
BORDER_WIDTH = 16
SEARCH_AREA = 25
DEFAULT_HEIGHT = 299
DEFAULT_WIDTH = 299
MIN_CONTOUR_POINTS = 5
ELEMENT_DEFAULT = 'Ellipse'
LOGGER_NAME = 'app_logger.'

logger = logging.getLogger(LOGGER_NAME + __name__)


class Image:
    formats = ['.jpg', '.png', '.jpeg', '.tiff']
    metadata = ['.csv']

    def is_valid_format(path=None):
        """
        Static method to validate if format
        of the image is in Image.formats

        :return: Boolean
        """

        if ("." + path.split('.')[-1]) in Image.formats:
            logger.debug(f'Path: {path} in valid formats!')
            return True
        return False

    def __init__(self, path=None):
        """
        Default constructor for the Image class

        :param path: path to image
        """

        self.path = self.dir = self.name = self.format \
            = self.thresholded = self.gray = self.copy \
            = self.shape = self.masked = self.loaded_mask \
            = self.contours = self.morph_open \
            = self.opened = self.scaled = None
        self.init_properties(path)
        self.img = self.load(self.path)
        logger.info('Image initialization successful!')

    def init_properties(self, path=None):
        """
        Method sets the properties of the loaded
        image

        :param path: path to an image
        :return: None
        """

        if path:
            if Image.is_valid_format(path):
                self.path = path
                self.dir = '\\'.join(self.path.split('\\')[:-1]) + '\\'
                self.name = path.split('\\')[-1]
                self.format = '.' + self.name.split('.')[-1]
                logger.debug(f'Init args: {self.path}, {self.dir}'
                             f' ,{self.name}, {self.format}')

    def load(self, path=None):
        """
        Method loads an image from path

        :param path: path to an image
        :return: None or loaded img
        """

        if self.path is None and path is None:
            return None
        else:
            if self.path is None:
                self.init_properties(path)
                self.img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
                self.shape = self.get_shape()
                self.copy = cp.deepcopy(self.img, cv2.IMREAD_UNCHANGED)
            else:
                self.img = cv2.imread(self.path, cv2.IMREAD_UNCHANGED)
                self.shape = self.get_shape()
                self.copy = cp.deepcopy(self.img)

            if len(self.shape) == 2:
                self.loaded_mask = True
            else:
                self.loaded_mask = False
            logger.info(f'Img loaded successfully!')
            logger.debug(f'Loaded image: {self.name}, path: {self.path}')
            return self.img

    def reload(self):
        """
        Method reloads an Image from the path
        :return: Image object
        """

        if self.path is not None:
            logger.debug(f'Image {self.name} reloaded!')
            return Image(self.path)

    def reload_data(self):
        """
        Method reloads only data of the image
        :return:  None
        """

        if self.path is not None:
            self.img = cv2.imread(self.path,
                                  cv2.IMREAD_UNCHANGED)
            self.copy = cp.deepcopy(self.img)
            self.shape = self.get_shape()
            self.gray \
                = self.thresholded \
                = self.masked = None
            logger.debug(f'Image {self.name} data reloaded!')

    def check_format(self, format=None):
        """
        Method checks if the format is in
        supported formats

        :param format: format to check
        :return: format
        """

        if format in Image.formats:
            return format
        else:
            return self.format

    def get_image_name(self):
        """
        Method return Image name in a more readable way
        if lenght is more than 20 characters
        :return: Image name
        """

        logger.debug(f'Image name: {self.name}')
        if len(self.name) > 25:
            return self.name[:25] + ' ...' + 'png'
        else:
            return self.name

    def check_format_in_name(self, new_name):
        """
        Method check if a new_name contains
        format

        :param new_name: new_name of the image
        :return: new_name, format
        """

        logger.debug(f'New name of image: {new_name}')
        if new_name is not None:
            format = '.' + new_name.split('.')[-1]
            new_name = new_name.split('.')[0]
            return new_name, format
        return new_name, self.format

    def to_binary(self):
        """
        Method converts grey thresholded regions
        to black
        :return: None
        """

        logger.debug(f'Image is to be converted to binary')
        self.img[(self.img > BLACK_VALUE) & (self.img < WHITE_VALUE)] = BLACK_VALUE

    def save(self, new_name=None, format=None, dst=None):
        """
        Method saves an image mask to a disk

        :param new_name: New name for saved image
        :param format: Format of image to be saved
        :param dst: Destination directory to be saved
        :return: None
        """

        new_name, format = self.check_format_in_name(new_name)
        self.to_binary()

        if dst is None:
            cv2.imwrite(self.dir + self.name + self.check_format(format) if new_name is None else
                        self.dir + new_name + self.check_format(format), self.img)
        else:
            cv2.imwrite(dst + '\\' + self.name + self.check_format(format) if new_name is None
                        else dst + '\\' + new_name + self.check_format(format), self.img)
        logger.debug(f'Image name: {new_name} is saved to: {dst if dst is not None else self.dir}')

    def save_original(self, name, format, dst):
        """
        Method saves an image to a disk

        :param name: New name for saved image
        :param dst: Destination directory to be saved
        :return: None
        """

        self.reload_data()
        self.highlight_borders(CHNL=3)
        new_name, new_format = self.check_format_in_name(name)
        format = self.check_format(format)

        if format is None:
            format = new_format

        cv2.imwrite(dst + '\\' + new_name + self.check_format(format), self.img)
        logger.debug(f'Image name: {new_name} saved as original to: {dst}')

    def get_width(self):
        """
        Method returns width of the image
        :return: width
        """

        if self.img is not None:
            return self.img.shape[0]

    def get_height(self):
        """
        Method return height of the image
        :return: height
        """

        if self.img is not None:
            return self.img.shape[1]

    def get_shape(self):
        """
        Method return shape of the image
        :return: tuple of shape
        """

        if self.img is not None:
            if self.img.shape[0] != DEFAULT_WIDTH \
                    or self.img.shape[1] != DEFAULT_HEIGHT:
                self.scaled = True
                self.sf_x = DEFAULT_HEIGHT / self.img.shape[1]
                self.sf_y = DEFAULT_WIDTH / self.img.shape[0]
                logger.debug(f'Image scaled X: {self.sf_x}, Y: {self.sf_y}')
            else:
                self.scaled = False
            return self.img.shape

    def highlight_borders(self, bord_width=BORDER_WIDTH, CHNL=2):
        """
        Method highlights borders with defined
        BORDER_WIDTH to yellow colour.

        :param CHNL:
        :param bord_width:
        :return: None
        """

        if bord_width is not None and 0 < bord_width < self.get_height() \
                and bord_width < self.get_width():
            x, y = self.get_shape()[:2]

            if self.loaded_mask:
                self.img[0: bord_width, :] = WHITE_VALUE
                self.img[:, 0:bord_width] = WHITE_VALUE
                self.img[x - bord_width:, :] = WHITE_VALUE
                self.img[:, y - bord_width:] = WHITE_VALUE
            else:
                self.img[0: bord_width, :, :CHNL] = WHITE_VALUE
                self.img[:, 0:bord_width, :CHNL] = WHITE_VALUE
                self.img[x - bord_width:, :, :CHNL] = WHITE_VALUE
                self.img[:, y - bord_width:, :CHNL] = WHITE_VALUE
            logger.debug(f'Image highlighted successfully!')

    def blacken_borders(self, bord_width=BORDER_WIDTH):
        """
        Method highlight borders with defined
        BORDER_WIDTH to BLACK_VALUE

        :param bord_width: border width
        :return: None
        """

        x, y = self.get_shape()[:2]
        self.img[0: bord_width, :] = BLACK_VALUE
        self.img[:, 0:bord_width] = BLACK_VALUE
        self.img[x - bord_width:, :] = BLACK_VALUE
        self.img[:, y - bord_width:] = BLACK_VALUE
        logger.debug(f'Image borders blacken successfully!')

    def fill_4n_pixels(self, x, y):
        """
        Method highlight cursor in position
        of x, y to red value

        :param x: x position of pixel
        :param y: y position of pixel
        :return: None
        """

        if not self.loaded_mask:
            self.img[x - 1:x + 2, y - 1:y + 2, 2] = WHITE_VALUE
            self.img[x - 1:x + 2, y - 1:y + 2, :2] = BLACK_VALUE
        logger.debug(f'Image pixels filled successfully!')

    def to_gray(self):
        """
        Method processes an image to gray image
        Note that gray image has only 1 color channel
        :return: None
        """

        if self.img is not None:
            if self.loaded_mask:
                return

            self.shape = (self.shape[:2])

            if self.gray is None:
                self.img = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
                self.gray = True
            else:
                self.img = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
            logger.debug(f'Image grayed successfully!')

    def adaptive_threshold(self, threshold=THRESHOLD_VALUE, neighbours=NEIGHBOURS_VALUE):
        """
        Method process an image to binary thresholding
        using adaptive threshold
        :return: None
        """

        if neighbours % 2 == 0:  # Neighbours value must be odd, minus one if is even
            neighbours -= 1

        if self.loaded_mask:
            return

        if self.img is not None:
            if self.gray is None:
                self.to_gray()
            if self.thresholded is None:
                self.thresholded = True
                self.img = cv2.adaptiveThreshold(self.img, GREY_VALUE, cv2.ADAPTIVE_THRESH_MEAN_C,
                                                 cv2.THRESH_BINARY_INV,
                                                 neighbours,
                                                 threshold)
                self.blacken_borders()
            else:
                self.img = cp.deepcopy(self.copy)
                self.to_gray()
                self.img = cv2.adaptiveThreshold(self.img, GREY_VALUE, cv2.ADAPTIVE_THRESH_MEAN_C,
                                                 cv2.THRESH_BINARY_INV,
                                                 neighbours,
                                                 threshold)
                self.blacken_borders()
            logger.debug(f'Image thresholded successfully!')

    def in_background(self, x, y, threshold=THRESHOLD_VALUE, neighbours=NEIGHBOURS_VALUE):
        """
        Method checks if click in (x, y) belongs
        to foreground (black pixels)

        :param neighbours: actual value of neighbours
        :param threshold: acutal value of threshold
        :param x: x position of the click
        :param y: y position of the click
        :return: Boolean
        """

        img = cp.deepcopy(self.img)
        self.adaptive_threshold(threshold, neighbours)

        if self.img[y, x] == BLACK_VALUE:
            self.img = img
            return True
        self.img = img
        return False

    def in_added(self, x, y):
        """
        Method checks if the click in (x, y) belongs
        to selected regions or not

        :param x: x position of the click
        :param y: y position of the click
        :return: Boolean
        """

        if self.img[y, x] == WHITE_VALUE:
            return True
        return False

    def growing_region(self, coords, thresh=THRESHOLD_VALUE, neigh=NEIGHBOURS_VALUE):
        """
        Method selects regions defined in coords as position
        x,y and create new image from it

        :param coords: X,Y coordinations of ROI
        :param thresh: Thresh value to be used
        :param neigh: Neigh value to be used
        :return: New Image with ROIs
        """

        if coords is not None:
            if self.masked is True:
                self.adaptive_threshold(thresh, neigh)

            mask = self.extract(coords)
            self.masked = True
            self.img[(mask > BLACK_VALUE)] = WHITE_VALUE
            self.draw_contours()
        logger.debug(f'Image regions selected successfully!')

    def add_new_region(self, x, y, thresh=THRESHOLD_VALUE, neigh=NEIGHBOURS_VALUE):
        """
        Method adds a new region to selected regions

        :param x: x position of region
        :param y: y position of region
        :param thresh: default threshold
        :param neigh: default neighbours
        :return: None
        """

        img_tmp = cp.deepcopy(self.img)
        self.reload_data()
        self.adaptive_threshold(thresh, neigh)

        mask = self.extract((x, y))
        img_tmp[mask > BLACK_VALUE] = WHITE_VALUE
        self.img = cp.deepcopy(img_tmp)
        self.draw_contours()
        logger.debug(f'Image new regions added successfully!')

    def extract(self, roi, threshold=THRESHOLD_VALUE, neighbours=NEIGHBOURS_VALUE):
        """
        Method extracts regions from coordinates

        :param neighbours: Number of neighbours
        :param threshold: Value of threshold
        :param roi: coordinates list or tuple of (x,y)
        :return: extracted mask
        """

        if len(roi) > 0:
            h, w = self.img.shape[:2]
            mask = np.zeros((h + 2, w + 2), np.uint8)
            floodflags = 4
            floodflags |= cv2.FLOODFILL_MASK_ONLY
            floodflags |= (255 << 8)

            if not isinstance(roi, list):
                _, img, mask, _ = cv2.floodFill(self.img, mask, roi, (WHITE_VALUE, 0, 0),
                                                (10,) * 3, (10,) * 3, floodflags)
            else:
                for pos in roi:
                    _, img, mask, _ = cv2.floodFill(self.img, mask, pos, (WHITE_VALUE, 0, 0),
                                                    (10,) * 3, (10,) * 3, floodflags)
            mask = mask[1:h + 1, 1:w + 1]
            logger.debug(f'Image regions floodfilled successfully!')
            return mask

    def extract_regions(self, coords):
        """
        Method extracts regions from coordinates
        and draw the regions in image

        :param coords: List of coordinates (x, y)
        :return: None
        """

        if coords is not None:
            h, w = self.img.shape[:2]
            mask = np.zeros((h + 2, w + 2), np.uint8)
            floodflags = 4
            floodflags |= cv2.FLOODFILL_MASK_ONLY
            floodflags |= (255 << 8)
            for roi in coords:
                _, img, mask, _ = cv2.floodFill(self.img, mask, roi, (WHITE_VALUE, 0, 0),
                                                (10,) * 3, (10,) * 3, floodflags)
            self.masked = True
            mask = mask[1:h + 1, 1:w + 1]
            self.img = mask
            self.draw_contours()
            logger.debug(f'Image regions extracted successfully!')

    def find_center(self, x, y, img=None):
        """
        Method tries to find new center
        after morphological open if  the
        original does not match

        :param img: image with contour
        :param x: original x position
        :param y: original y position
        :return: List of found center (x, y)
        """

        if img is None:
            for i in range(0, SEARCH_AREA):
                if self.morph_open[y + i, x] == WHITE_VALUE:
                    return [(y + i, x)]
                if self.morph_open[y - i, x] == WHITE_VALUE:
                    return [(y - i, x)]
                if self.morph_open[y, x + i] == WHITE_VALUE:
                    return [(y, x + i)]
                if self.morph_open[y, x - i] == WHITE_VALUE:
                    return [(y, x - i)]
                if self.morph_open[y + i, x + i] == WHITE_VALUE:
                    return [(y + i, x + i)]
                if self.morph_open[y + i, x - i] == WHITE_VALUE:
                    return [(y + i, x - i)]
                if self.morph_open[y - i, x + i] == WHITE_VALUE:
                    return [(y - i, x + i)]
                if self.morph_open[y - i, x - i] == WHITE_VALUE:
                    return [(y - i, x - i)]
            logger.error(f"CENTER NOT FOUND: x:{x}, y:{y}")
        else:
            for i in range(0, SEARCH_AREA):
                if img[y + i, x] == WHITE_VALUE:
                    return [(y + i, x)]
                if img[y - i, x] == WHITE_VALUE:
                    return [(y - i, x)]
                if img[y, x + i] == WHITE_VALUE:
                    return [(y, x + i)]
                if img[y, x - i] == WHITE_VALUE:
                    return [(y, x - i)]
                if img[y + i, x + i] == WHITE_VALUE:
                    return [(y + i, x + i)]
                if img[y + i, x - i] == WHITE_VALUE:
                    return [(y + i, x - i)]
                if img[y - i, x + i] == WHITE_VALUE:
                    return [(y - i, x + i)]
                if img[y - i, x - i] == WHITE_VALUE:
                    return [(y - i, x - i)]
            logger.error(f"CENTER NOT FOUND: x:{x}, y:{y}")

    def not_in_mask(self, coords):
        """
        Method find all coordinates that
        does not belong morphed area

        :param coords: List of coordinates (x,y)
        :return: List of non contained coordinates (x,y)
        """

        new = []

        if coords:
            for roi in coords:
                if self.mask[roi[1], roi[0]] != WHITE_VALUE:
                    new.append(roi)
        return new

    def structuring_element(self, default=ELEMENT_DEFAULT, size=ELEMENT_VALUE):
        """
        Method returns selected structuring element
        for morphological opening operation

        :param size: Size of structuring element
        :param default: Default element Elipse
        :return: cv2.structuring element
        """

        if default == 'Rectangular':
            return cv2.getStructuringElement(cv2.MORPH_RECT, (size, size))
        elif default == 'Cross':
            return cv2.getStructuringElement(cv2.MORPH_CROSS, (size, size))
        else:  # Default structuring element - Ellipse
            return cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (size, size))

    def morph_open_global(self, element=ELEMENT_DEFAULT, size=ELEMENT_VALUE):
        """
        Method applies morphology erosion and then
        dilatation to image after growing region.
        It is used to separate connected cells (ROIs)

        :param element: Specified structuring element
        :param size: Specified size of the element
        :return: None
        """

        if self.masked:
            self.img[(self.img > BLACK_VALUE) & (self.img < WHITE_VALUE)] = BLACK_VALUE
            struct_elem = self.structuring_element(element, size)
            self.img = cv2.morphologyEx(self.img, cv2.MORPH_OPEN, struct_elem)
            logger.debug(f'Image morphological open globally applied!')

    def region_open(self, x, y, element=ELEMENT_DEFAULT, size=ELEMENT_VALUE):
        """
        Method performs a morphological open in
        the region that has x, y coordinates

        :param element: Specified structuring element
        :param size: Specified size of the element
        :param x: x position of region
        :param y: y position of region
        :return: None or Centers [int]
        """

        self.mask = self.extract((x, y))
        self.morph_open = cp.deepcopy(self.mask)

        struct_elem = self.structuring_element(element, size)
        self.morph_open = cv2.morphologyEx(self.morph_open, cv2.MORPH_OPEN, struct_elem)

        if self.morph_open.max() != BLACK_VALUE:
            centers = []
            contours, _ = cv2.findContours(image=self.morph_open,
                                           mode=cv2.RETR_EXTERNAL,
                                           method=cv2.CHAIN_APPROX_SIMPLE)
            if len(contours) == 1:
                if self.morph_open[y, x] == WHITE_VALUE:
                    centers.append((x, y))
                    return centers
                else:
                    new_center = self.find_center(x, y)
                    new_x = new_center[0][1]
                    new_y = new_center[0][0]
                    return [(new_x, new_y)]
            else:
                for index, contour in enumerate(contours):
                    if len(contour) >= MIN_CONTOUR_POINTS:
                        (x, y), (MA, ma), angle = cv2.fitEllipse(contour)
                        center = (int(x), int(y))
                        # If center is outbound, try to find it
                        if self.morph_open[center[1], center[0]] != 255:
                            img = np.zeros((self.img.shape[:2]), np.uint8)
                            img = cv2.drawContours(img, [contour], 0,
                                                   (WHITE_VALUE,
                                                    WHITE_VALUE,
                                                    WHITE_VALUE),
                                                   cv2.FILLED)
                            new_center = self.find_center(center[0], center[1], img)
                            new_x = new_center[0][1]
                            new_y = new_center[0][0]
                            # centers.extend(self.find_center(center[0], center[1], img))
                            centers.append((new_x, new_y))
                        else:
                            centers.append(center)
                    else:
                        img = np.zeros((self.img.shape[:2]), np.uint8)
                        img = cv2.drawContours(img, [contour], 0,
                                               (WHITE_VALUE,
                                                WHITE_VALUE,
                                                WHITE_VALUE),
                                               cv2.FILLED)
                        new_center = self.find_center(x, y, img)
                        if new_center:
                            new_x = new_center[0][1]
                            new_y = new_center[0][0]
                            centers.append((new_x, new_y))
                return centers
        return None

    def merge_regions(self, coords):
        """
        Method merge opened and selected regions together

        :param coords: Selected coordinates {Tuple}
        :return: New centers of regions
        """

        new = []
        # Remove already added regions
        if coords:
            for coord in coords:
                if self.mask[coord[1], coord[0]] != WHITE_VALUE:
                    new.append(coord)
            self.extract_regions(new)
            self.img[self.morph_open > BLACK_VALUE] = WHITE_VALUE
        else:
            self.img = cp.deepcopy(self.morph_open)
        self.opened = True
        self.draw_contours()
        logger.debug(f'Image regions merged successfully!')

    def delete_region(self, x, y, coords):
        """
        Method deletes region which belongs to
        coordinates with x, y
        :param x: x position of the click
        :param y: y position of the click
        :param coords: all coordinates
        :return: List of remaining ROIs
        """

        new = []

        if len(coords) == 1:
            return []

        self.morph_open = self.extract((x, y))
        for roi in coords:
            if self.morph_open[roi[1], roi[0]] != WHITE_VALUE:
                new.append(roi)

        if len(new) > 0:
            self.extract_regions(new)
        logger.debug(f'Image region deleted successfully!')
        return new

    def draw_contours(self):
        """
        Method draws found contours in image
        If contour contains black pixes, it will be
        filled with WHITE VALUE
        :return:  None
        """

        self.find_countours()
        self.img = cv2.drawContours(self.img, self.contours, -1, (WHITE_VALUE, WHITE_VALUE, WHITE_VALUE), cv2.FILLED)
        logger.debug(f'Image contours drawn!')

    def find_centers(self):
        """
        Method returns found centers
        for each contour
        :return: None
        """

        centers = []
        self.opened = True
        self.find_countours()
        for index, contour in enumerate(self.contours):
            if len(contour) >= 5:
                (x, y), (MA, ma), angle = cv2.fitEllipse(contour)
                center = (int(x), int(y))
                img = np.zeros((self.img.shape[:2]), np.uint8)
                img = cv2.drawContours(img, [contour], 0,
                                       (WHITE_VALUE,
                                        WHITE_VALUE,
                                        WHITE_VALUE),
                                       cv2.FILLED)
                # If found center is outbound contour
                if img[center[1], center[0]] == BLACK_VALUE:
                    new_center = self.find_center(center[0], center[1], img)
                    new_x = new_center[0][1]
                    new_y = new_center[0][0]
                    centers.append((new_x, new_y))
                else:
                    centers.append(center)
        return centers

    def find_countours(self):
        """
        Method finds contours in the image
        :return: Number of contours
        """

        img = cp.deepcopy(self.img)
        img[(img > BLACK_VALUE) & (img < WHITE_VALUE)] = BLACK_VALUE
        self.contours, _ = cv2.findContours(image=img,
                                            mode=cv2.RETR_EXTERNAL,
                                            method=cv2.CHAIN_APPROX_SIMPLE)
        logger.debug(f'Image contours found successfully!')


if __name__ == '__main__':
    import os

    img = Image(r'‪C:\Users\grofc\Desktop\fasting.jpg')
    print(img.name)
    print(img.shape)

    print(os.path.isfile(r'C:\Users\grofc\Desktop\fasting.jpg'))
    i = cv2.imread(r'‪C:\Users\grofc\Desktop\fasting.jpg')
    print(i.shape)
