"""
Main View class to represent UI
"""

import sys
import webbrowser
import logging
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import Qt, QSize
from controller.controller import Controller
from PyQt5 import QtWidgets, QtGui, uic

DOC_URL = 'https://github.com/PavolGrofcik/LystoX'
ABOUT_URL = 'https://github.com/PavolGrofcik/LystoX/blob/master/About.md'
FILE_UI = './resources/configs/lystox_design.ui'
SAVE_FORMATS = '.png;;.jpeg;;.jpeg;;.tiff'
SUPPORTED_FILES = '*.png;;*.jpg;;*.tiff;;*.jpeg'
VAL_THRESHOLD = 33
VAL_NEIGHBOURS = 41
VAL_ELEMENT = 9
DEFAULT_ELEM_INDEX = 0

WIN_HEIGHT = 834
WIN_WIDTH = 1035
WIN_ICON = './resources/icons/LX.png'
WIN_TITLE = './resources/icons/LystoX_title.png'
WIN_TITLE2 = './resources/icons/title2.png'
WIN_RIGHT_IMAGE = './resources/icons/Tcells2.png'
WIN_LEFT_IMAGE = './resources/icons/Mask2.png'

LBL_HEIGHT = 299
LBL_WIDTH = 299
LBL_OK = './resources/icons/ok.png'
LBL_ERROR = './resources/icons/not.png'
LBL_NO_IMAGES = 'No Images found!'
LBL_SAVE_DISABLED = 'Automatic saving off!'
LBL_SAVE_ENABLED = 'Automatic saving on!'

LOGGER_NAME = 'app_logger.'

logger = logging.getLogger(LOGGER_NAME + __name__)


class Window(QtWidgets.QMainWindow):

    def __init__(self):
        """
        Method constructs a new Window and starts the application
        """

        super(Window, self).__init__()
        self.setFixedSize(QSize(WIN_WIDTH, WIN_HEIGHT))
        uic.loadUi(FILE_UI, self)
        self.setWindowIcon(QtGui.QIcon(WIN_ICON))
        self.action_handler()
        self.controller = Controller()
        self.to_intro()
        self.show()
        logger.info(f"View initilization successful!")

    def action_handler(self):
        """
        Method initiates menu actions to functions

        :return: None
        """

        self.act_open_dir.triggered.connect(self.open_directory)
        self.act_exit.triggered.connect(sys.exit)
        self.act_about.triggered.connect(self.to_about)
        self.act_open_file.triggered.connect(self.open_file_from_directory)
        self.act_doc.triggered.connect(self.to_doc)
        self.image_widget_set = False
        logger.info(f"Action handler initilization successful!")

    def signal_handler(self):
        """
        Method initiates the selected widget actions to functions

        :return: None
        """

        if self.stackedWidget.currentIndex() == 1:
            self.btn_next.clicked.connect(self.load_next_images)
            self.btn_next.setFocus()
            self.btn_prev.clicked.connect(self.load_previous_images)
            self.btn_save.clicked.connect(self.save_mask)
            self.btn_reset.clicked.connect(self.reset_images)
            self.btn_del.clicked.connect(self.delete_selected_item)
            self.btn_del_all.clicked.connect(self.delete_all_items)
            self.btn_open.clicked.connect(self.morphology_global)
            self.act_reset.triggered.connect(self.reset_images)
            self.act_dst_dir.triggered.connect(self.set_destination_directory)
            self.act_save_as.triggered.connect(self.save_preview_as)
            self.act_aut_save.triggered.connect(self.aut_save_info)
            self.lbl_cont_info.hide()
            self.lbl_img.mousePressEvent = self.add_roi_handler
            self.lbl_img.mouseMoveEvent = self.show_mouse_coords
            self.lbl_prev.mousePressEvent = self.process_roi_handler
            self.lbl_prev.mouseMoveEvent = self.show_mouse_coords
            self.lbl_img.setMouseTracking(True)
            self.lbl_prev.setMouseTracking(True)
            self.sliders_default_state()
            self.sld_thresh.valueChanged[int].connect(self.threshold_preview)
            self.sld_neigh.valueChanged[int].connect(self.threshold_preview)
            self.sld_thresh.sliderReleased.connect(self.set_input_fields)
            self.sld_neigh.sliderReleased.connect(self.set_input_fields)
            self.img_input.returnPressed.connect(self.load_selected_image)
            self.thresh_input.returnPressed.connect(self.set_sliders)
            self.neigh_input.returnPressed.connect(self.set_sliders)
            logger.info(f"Signal handler initilization successful!")

    def to_intro(self):
        """
        Init method to show into window
        or if config file is specified
        loads directly image window

        :return: None
        """

        if self.controller.load_cfg_directory():
            self.to_image()
            self.load_first_images()
            logger.debug(f"Load config initilization successful!")
        else:
            self.home_widget_set = True
            self.stackedWidget.setCurrentWidget(self.HomeWidget)
            self.label_title.setPixmap(QtGui.QPixmap(WIN_TITLE))
            self.label_right.setPixmap(QtGui.QPixmap(WIN_RIGHT_IMAGE))
            self.label_left.setPixmap(QtGui.QPixmap(WIN_LEFT_IMAGE))
            self.btn_load.clicked.connect(self.open_directory)
            self.set_image_actions()
            logger.debug(f"Default initilization successful!")

    def to_about(self):
        """
        Method opens about url in web browser

        :return: None
        """

        webbrowser.open(ABOUT_URL)

    def to_doc(self):
        """
        Method opens doc url in web browser

        :return: None
        """

        webbrowser.open(DOC_URL)

    def to_image(self):
        """
        Method changes ImageWidget in current window

        :return: None
        """

        if self.image_widget_set is True:
            self.stackedWidget.removeWidget(self.ImageWidget)
            self.stackedWidget.insertWidget(1, self.ImageWidget)

        self.image_widget_set = True
        self.stackedWidget.setCurrentWidget(self.ImageWidget)
        self.signal_handler()
        self.clear_image_widget()
        self.set_image_actions()
        logger.debug(f"First images initilization successful!")

    def set_image_actions(self):
        """
        Method enables specific action
        for image widget

        :return: None
        """

        if self.image_widget_set is True:
            self.act_aut_save.setEnabled(True)
            self.act_reset.setEnabled(True)

        if self.controller.autosave:
            self.act_aut_save.setChecked(True)

    def open_file_from_directory(self):
        """
        Method loads selected file and opens a directory

        :return: None
        """

        self.loaded_file, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open File", "./",
                                                                    SUPPORTED_FILES)
        if self.loaded_file != '' and self.loaded_file is not None:
            self.controller.open_directory(self.loaded_file, is_file=True)
            if self.controller.dir is None or self.controller.is_empty_directory():
                self.msg_box_no_images()
                self.loaded_file, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open File", "./",
                                                                            SUPPORTED_FILES)
                if self.loaded_file != '' and self.loaded_file is not None:
                    self.controller.open_directory(self.loaded_file, is_file=True)
                    if self.controller.dir is None or self.controller.is_empty_directory():
                        self.msg_box_failed_to_load()
                        logger.debug(f'Failed to load file!')
                        sys.exit()
                    else:
                        if self.stackedWidget.currentIndex() == 1:
                            self.load_first_images()
                        else:
                            self.to_image()
                            self.load_first_images()
            else:
                if self.stackedWidget.currentIndex() == 1:
                    self.load_first_images()
                else:
                    self.to_image()
                    self.load_first_images()

    def open_directory(self):
        """
        Method opens directory dialog and loads Image widget
        if user selected directory

        :return: None
        """

        self.loaded_dir = QtWidgets.QFileDialog.getExistingDirectory(self, "Open Directory", "./")
        if self.loaded_dir != '' and self.loaded_dir is not None:
            self.controller.open_directory(self.loaded_dir)
            if self.controller.dir is None or self.controller.is_empty_directory():
                self.msg_box_no_images()  # Load again else exit app
                self.loaded_dir = QtWidgets.QFileDialog.getExistingDirectory(self, "Open Directory", "./")

                if self.loaded_dir != '' and self.loaded_dir is not None:
                    self.controller.open_directory(self.loaded_dir)
                    if self.controller.dir is None or self.controller.is_empty_directory():
                        self.msg_box_failed_to_load()
                        logger.debug(f'Failed to load directory!')
                        sys.exit()
                    else:
                        if self.stackedWidget.currentIndex() == 1:
                            self.load_first_images()
                        else:
                            self.to_image()
                            self.load_first_images()
            else:
                if self.stackedWidget.currentIndex() == 1:
                    self.load_first_images()
                else:
                    self.to_image()
                    self.load_first_images()

    def set_destination_directory(self):
        """
        Method opens dialog to select destination directory
        and sets the destination directory if chosen

        :return: None
        """

        self.new_dir = QtWidgets.QFileDialog.getExistingDirectory(self, "Set destination Directory", "./")
        if self.new_dir != '' and self.new_dir is not None:
            logger.debug(f'Destination directory to be set: {self.new_dir}')
            self.controller.set_dst_directory(self.new_dir)
            self.set_directory_info()

    def save_preview_as(self):
        """
        Method opens a save dialog to save mask with
        optional formats and destination
        :return: None
        """

        options = QtWidgets.QFileDialog.Options()
        file, format = QtWidgets.QFileDialog.getSaveFileName(self, "Save As...", "",
                                                             SAVE_FORMATS,
                                                             options=options)
        if file is not None and file != "":
            logger.debug(f'Filename: {file}, format: {format}')
            self.controller.save_preview_image(*self.controller.parse_info_to_save_as(file, format))
            self.lbl_status.setText("Img '{}' saved!".format(file.split('/')[-1] + format))

    def set_source_image(self, qimage=None, img_name=None):
        """
        Method sets the source image with dependencies
        :param qimage: qimage to be set in Qlabel
        :param img_name: image name
        :return: None
        """

        if qimage is not None and img_name is not None:
            self.image_src = qimage
            self.pixmap_src = QtGui.QPixmap.fromImage(self.image_src)
            # new
            self.pixmap_src = self.pixmap_src.scaled(LBL_HEIGHT, LBL_WIDTH, Qt.IgnoreAspectRatio,
                                                     Qt.FastTransformation)
            self.lbl_img.setPixmap(self.pixmap_src)
            self.lbl_src_name.setText(img_name)
            self.set_source_img_info(img_name)
        else:
            self.lbl_status.setText(LBL_NO_IMAGES)
        logger.debug(f'Source image set successful!')

    def set_preview_image(self, qimage=None, img_name=None):
        """
        Method sets the preview image with dependencies

        :param qimage: qimage to be in Qlabel
        :param img_name: image name
        :return: None
        """

        if qimage is not None and img_name is not None:
            self.image_prev = qimage
            self.pixmap_prev = QtGui.QPixmap.fromImage(self.image_prev)
            self.pixmap_prev = self.pixmap_prev.scaled(LBL_HEIGHT, LBL_WIDTH, Qt.IgnoreAspectRatio,
                                                       Qt.FastTransformation)
            self.lbl_prev.setPixmap(self.pixmap_prev)
            self.prev_input.setText(img_name)
            logger.debug(f'Preview image set successful!')

    def set_source_img_info(self, img_name):
        """
        Method sets the information about number
        of lymphocytes in the image and a number of
        the loaded image from all images

        :param img_name: image name
        :return: None
        """

        self.lbl_lymph.setText(self.controller.get_lymphocytes(img_name))
        self.img_input.setText(self.controller.get_img_index())
        self.lbl_load_info.setText(self.controller.get_imgs_length())

    def load_first_images(self):
        """
        Method loads the first images from the directory
        :return: None
        """

        self.set_input_fields()
        self.set_directory_info()
        self.controller.highlight_borders()
        self.set_source_image(*self.controller.get_image_data(False))
        self.threshold_preview()
        self.aut_save_info()

    def load_next_images(self):
        """
        Method loads next images from the directory and
        saves the preview image if automatically save is
        enabled
        :return: None
        """

        self.clear_dependencies()
        if self.act_aut_save.isChecked():
            self.save_mask()
        else:
            self.lbl_status.setText(LBL_SAVE_DISABLED)
        self.controller.load_next_image()
        self.controller.highlight_borders()
        self.set_source_image(*self.controller.get_image_data(False))
        self.threshold_preview()

    def load_previous_images(self):
        """
        Method loads previous images from the
        directory
        :return: None
        """

        self.clear_dependencies()
        if self.act_aut_save.isChecked():
            self.save_mask()
        else:
            self.lbl_status.setText(LBL_SAVE_DISABLED)
        self.controller.load_next_image(prev=True)
        self.controller.highlight_borders()
        self.set_source_image(*self.controller.get_image_data(False))
        self.threshold_preview()

    def load_selected_image(self):
        """
        Methods loads an image from the selected index

        :return: None
        """

        img_num = self.img_input.text()
        logger.debug(f'Image num to be loaded: {img_num}!')
        self.clear_dependencies()
        if self.controller.load_selected_image(img_num):
            self.load_first_images()
        else:
            self.img_input.setText(self.controller.get_img_index())
            self.lbl_load_info.setText(self.controller.get_imgs_length())
        self.btn_next.setFocus(True)

    def save_mask(self):
        """
        Method saves mask to destination if a metadata file
        has been loaded
        :return: None
        """

        if self.controller.original:
            self.controller.save_source_image(self.controller.Image.name)
        self.controller.save_preview_mask(name=self.prev_input.text())
        self.lbl_status.setText("Img '{}' saved!".format(self.prev_input.text()))

    def highlight_borders(self):
        """
        Method highlights borders of the source image
        :return:
        """

        self.controller.highlight_borders()

    def sliders_default_state(self):
        """
        Method sets sliders to default state
        :return: None
        """

        self.sld_thresh.setValue(VAL_THRESHOLD)
        self.sld_neigh.setValue(VAL_NEIGHBOURS)
        self.sld_element.setValue(VAL_ELEMENT)
        self.box_element.setCurrentIndex(DEFAULT_ELEM_INDEX)
        self.set_input_fields()
        logger.debug(f'Sliders set to default state!')

    def set_directory_info(self):
        """
        Method set the information about loaded
        directory and destination
        :return:
        """

        self.lbl_directory.setText(self.controller.dir.get_src_name())
        self.lbl_destination.setText(self.controller.dir.get_dst_name())

    def set_input_fields(self):
        """
        Method sets the input field from values of the
        sliders if they have been changed
        :return: None
        """

        self.thresh_input.setText(str(self.sld_thresh.value()))
        self.neigh_input.setText(str(self.sld_neigh.value()))
        self.segment_region()

    def set_sliders(self):
        """
        Method sets sliders values from the input fields
        if they have been changed
        :return: None
        """

        try:
            self.sld_thresh.setValue(int(self.thresh_input.text()))
            self.sld_neigh.setValue(int(self.neigh_input.text()))
        except:
            self.sliders_default_state()

    def threshold_preview(self):
        """
        Method thresholds and sets the preview image
        :return: None
        """

        self.controller.threshold_image(self.sld_thresh.value(), self.sld_neigh.value())
        self.set_preview_image(*self.controller.get_image_data(True))

    def get_scale_xy(self, event):
        """
        Method returns scale x,y position of cursor from a mouse event

        :param event: Mouse event
        :return: Scaled x,y
        """

        ev_x, ev_y = event.x(), event.y()
        logger.debug(f'Mouse cursor X: {ev_x}, Y: {ev_y}!')

        if self.controller.Image.scaled:
            ev_x = event.x() / self.controller.Image.sf_x if self.controller.Image.sf_x < 1 \
                else event.x() / self.controller.Image.sf_x
            ev_y = event.y() / self.controller.Image.sf_y if self.controller.Image.sf_y < 1 \
                else event.y() / self.controller.Image.sf_y

        return int(ev_x), int(ev_y)

    def add_roi_handler(self, event):
        """
        Method selects new ROIs on the given position
        of click x and y and segments them if are correct

        :param event: Mouse click event in the image
        :return: None
        """

        if event.button() == Qt.LeftButton:
            #Scaling the image
            ev_x, ev_y = self.get_scale_xy(event)

            if self.controller.Image_prev.in_background(ev_x, ev_y,
                                                        self.sld_thresh.value(),
                                                        self.sld_neigh.value()):
                return

            if not self.controller.Image_prev.opened:  # Not black pixels selected
                if self.listview.count():

                    if not self.controller.Image_prev.in_added(ev_x, ev_y):
                        self.add_item_to_listview(event)
                        self.segment_region()
                else:
                    # Empty list
                    self.add_item_to_listview(event)
                    self.segment_region()
            else:
                # Morphological operation has been already applied
                if not self.controller.Image_prev.in_added(ev_x, ev_y):
                    self.controller.Image_prev.add_new_region(ev_x, ev_y,
                                                              self.sld_thresh.value(),
                                                              self.sld_neigh.value())
                    self.add_item_to_listview(event)
                    self.set_preview_image(*self.controller.get_image_data(True))
                    self.selection_info()

    def process_roi_handler(self, event):
        """
        Method deletes the selected roi or
        performs a morphological open to
        the selected roi

        :param event: Mouse click event in the image
        :return: None
        """

        # Scaling the image
        ev_x, ev_y = self.get_scale_xy(event)

        if event.button() == Qt.LeftButton:
            # Delete the selected ROI
            if self.controller.Image_prev.in_added(ev_x, ev_y):
                items = self.controller.delete_region(ev_x, ev_y,
                                                      self.get_list_items())
                if items:
                    self.set_processed_images(items)
                else:
                    self.reset_images()
        elif event.button() == Qt.RightButton:
            if self.listview.count():
                # Check if selected roi is in added region
                if not self.controller.Image_prev.in_added(ev_x, ev_y):
                    return

                element, size = self.select_element()
                center = self.controller.to_morphological_open(ev_x, ev_y, element, size)
                items = self.get_list_items()
                others = self.controller.find_positions_not_in_mask(items)
                self.controller.merge_regions(others)

                if others:  # Set preview image or if none reset image
                    if center:
                        others.extend(center)
                    self.set_processed_images(others)
                else:
                    if center:
                        self.set_processed_images(center)
                    else:
                        self.reset_images()

    def set_processed_images(self, items):
        """
        Method add items to listview and
        reloads images, previews ...
        :param items: items to be added
        :return: None
        """

        self.listview.clear()
        self.controller.Image.reload_data()
        self.controller.Image.highlight_borders()
        logger.debug(f'Image items to be set: {items}')

        if items:
            self.listview.addItems(items)
            self.highlight_positions(items)

        self.set_source_image(*self.controller.get_image_data())
        self.set_preview_image(*self.controller.get_image_data(True))
        self.selection_info()

    def add_item_to_listview(self, event):
        """
        Method adds event item to listview items
        It also checks if the item is not already
        in list, otherwise it adds
        :param event: mouse clicked event
        :return: None
        """

        items = None
        item_to = str("X: " + str(event.x()) + ' Y: ' + str(event.y()))
        ev_x, ev_y = self.get_scale_xy(event)

        if self.listview.count() > 0:
            items = [str(self.listview.item(i).text()) for i in range(self.listview.count())]
            if item_to not in items:
                self.highlight_cursor(ev_x, ev_y)
                self.listview.addItems([str("X: " + str(event.x()) + ' Y: ' + str(event.y()))])
        else:
            self.highlight_cursor(ev_x, ev_y)
            self.listview.addItems([str("X: " + str(event.x()) + ' Y: ' + str(event.y()))])

    def get_list_items(self):
        """
        Method return all items from listview
        :return: Listview items {list}
        """

        items = [str(self.listview.item(i).text()) for i in range(self.listview.count())]
        return items

    def highlight_positions(self, items):
        """
        Method highlights positions for
        all items in source image
        :param items: Items to be highlighted
        :return: None
        """

        if items:
            logger.debug(f'Items to be highlighted: {items}')
            for item in items:
                item = item.split(' ')
                x, y = int(item[1]), int(item[3])
                if self.controller.Image.scaled:
                    x = x / self.controller.Image.sf_x if self.controller.Image.sf_x < 1 \
                        else x / self.controller.Image.sf_x
                    y = y / self.controller.Image.sf_y if self.controller.Image.sf_y < 1 \
                        else y / self.controller.Image.sf_y
                self.highlight_cursor(int(x), int(y))

    def highlight_cursor(self, x, y):
        """
        Methods highlight cursor position after clicked in
        the image with red color
        :param x: X coordinate of cursor
        :param y: Y coordinate of cursor

        :return: Inplace
        """

        logger.debug(f'Item coords to be highlighted X: {x}, Y: {y}')
        self.controller.fill_pixels(y, x)
        self.set_source_image(*self.controller.get_image_data(False))

    def highlight_selected_items(self):
        """
        Methods highlights the other items
        after deletion some of the items

        :return: None
        """

        if self.listview.count() > 0:
            self.controller.Image.reload_data()
            self.controller.highlight_borders()
            items = [str(self.listview.item(i).text()) for i in range(self.listview.count())]

            for item in items:
                item = item.split(' ')
                x, y = int(item[1]), int(item[3])
                if self.controller.Image.scaled:
                    x = x / self.controller.Image.sf_x if self.controller.Image.sf_x < 1 \
                        else x / self.controller.Image.sf_x
                    y = y / self.controller.Image.sf_y if self.controller.Image.sf_y < 1 \
                        else y / self.controller.Image.sf_y
                self.controller.fill_pixels(int(y), int(x))
            self.set_source_image(*self.controller.get_image_data(False))
        else:
            self.delete_all_items()

    def show_mouse_coords(self, event):
        """
        Method prints current coordinates of mouse
        in the image

        :param event: Actual mouse event
        :return: None
        """

        self.lbl_pos.setText("Position X: {} Y: {}".format(event.x(), event.y()))

    def delete_selected_item(self):
        """
        Method deletes selected items from Listwidget

        :return: None
        """

        selected = self.listview.selectedItems()
        if selected:
            for item in selected:
                self.listview.takeItem(self.listview.row(item))
            self.highlight_selected_items()
            self.segment_region()

    def delete_all_items(self):
        """
        Method deletes all items from Listwidget

        :return: None
        """

        self.lbl_pos.clear()
        self.lbl_selection.clear()
        self.lbl_cont.clear()
        self.lbl_cont_info.hide()
        self.listview.clear()
        self.controller.initialize_images()
        self.controller.highlight_borders()
        self.load_first_images()
        logger.debug(f'Image delete regions successful!')

    def reset_images(self):
        """
        Method resets the images to default
        :return: None
        """

        self.clear_dependencies()
        self.sliders_default_state()
        self.controller.initialize_images()
        self.controller.highlight_borders()
        self.set_source_image(*self.controller.get_image_data(False))
        self.threshold_preview()
        logger.debug(f'Image reset successful!')

    def segment_region(self):
        """
        Method segments the added regions
        :return: None
        """

        if self.listview.count():
            items = [str(self.listview.item(i).text()) for i in range(self.listview.count())]
            self.controller.to_growing_region(items, self.sld_thresh.value(), self.sld_neigh.value())
            self.set_preview_image(*self.controller.get_image_data(True))
            self.selection_info()

    def select_element(self):
        """
        Method returns selected structuring element
        and specified size

        :return: str name, int size
        """

        element = str(self.box_element.currentText())
        size = int(self.sld_element.value())
        logger.debug(f'Structuring element: {element}, size: {size}')

        return element, size

    def morphology_global(self):
        """
        Method applies morphology operation to all selected
        regions
        :return: None
        """

        element, size = self.select_element()
        self.controller.Image_prev.morph_open_global(element, size)
        items = self.controller.find_centers()
        self.set_processed_images(items)
        logger.debug(f'Morphology global successful!')

    def selection_info(self):
        """
        Method checks if number of regions in
        preview image corresponds to number in
        metadata file if loaded
        :return: None
        """

        if self.controller.metadata is not None:
            if self.controller.analyze_contours():
                self.lbl_selection.clear()
                self.lbl_selection.setScaledContents(True)
                self.lbl_selection.setPixmap(QtGui.QPixmap(LBL_OK))
            else:
                self.lbl_selection.clear()
                self.lbl_selection.setScaledContents(True)
                self.lbl_selection.setPixmap(QtGui.QPixmap(LBL_ERROR))
        if self.controller.get_contours():
            self.lbl_cont_info.show()
            self.lbl_cont.setText(self.controller.get_contours())

    def aut_save_info(self):
        """
        Method informs about option changing
        for automatic save
        :return: None
        """

        if self.act_aut_save.isChecked():
            self.lbl_status.setText(LBL_SAVE_ENABLED)
        else:
            self.lbl_status.setText(LBL_SAVE_DISABLED)

    def clear_dependencies(self):
        """
        Method clears dependencies and set the default
        state of widgets
        :return: None
        """

        self.listview.clear()
        self.lbl_cont.clear()
        self.lbl_cont_info.hide()
        self.lbl_selection.clear()
        self.lbl_status.clear()
        self.lbl_pos.clear()
        self.lbl_load_info.clear()

    def clear_image_widget(self):
        """
        Method clears all dependencies in image widget
        :return: None
        """

        self.lbl_status.clear()
        self.lbl_selection.clear()
        self.lbl_img.clear()
        self.lbl_prev.clear()
        self.lbl_src_name.clear()
        self.lbl_pos.clear()
        self.lbl_directory.clear()
        self.lbl_destination.clear()
        self.prev_input.setText("")
        self.thresh_input.setText("")
        self.img_input.setText("")
        self.listview.clear()

    def msg_box_no_images(self):
        """
        Method opens Message box to inform about
        no supported images
        :return: None
        """

        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setText('No supported Images found!')
        msg_box.setWindowTitle('Directory status')
        msg_box.setStandardButtons(QMessageBox.Ok)
        msg_box.exec()

    def msg_box_failed_to_load(self):
        """
        Method opens Message box to inform about
        failed to load supported images
        :return: None
        """

        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Information)
        msg_box.setText('Failed to load supported Images!')
        msg_box.setWindowTitle('Directory status')
        msg_box.setStandardButtons(QMessageBox.Ok)
        msg_box.exec()


if __name__ == '__main__':
    sys = QtWidgets.QApplication(sys.argv)
    Window = Window()
    sys.exit(sys.exec_())
