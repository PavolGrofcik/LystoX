##############
Follow instructions to properly set up an application.
##############


##############
Instructions:
##############

1. Download proper version of Anaconda for you OS from: https://www.anaconda.com/products/individual 
2. After downloaded, launch the downloaded file an install it
3. When installation ran successful, unzip and extract 'LystoX_tool' directory do Desktop (or other location)
4. After extraction, choose 'Start' -> type 'Anaconda Prompt' -> and 'launch it as Administrator' (important)!
5. Navigate prompt to extracted directory
6. Run the following command in prompt 'conda env create -f env_reqs.yml' #env_reqs.txt is text file in the
   copied directory. It creates virtual environment with required libraries and their specific requirements
7. After environment was successfully created, activate it using comand 'conda activate Lystox'
8. Navigate one level deeper in extracted directory using command 'cd ./LystoX'
9. Before running aplication, you can modify config.yml file to adjust your requirements in './resources/configs/config.yaml'
10. Run application with command 'python ./main.py'
11. Enjoy using it!


##############
In som cases, there can be problems with installed modeles. In that case, use either 'conda install -<modele_name>'
or pip installer 'pip install <module>' for missing <module/s>. 
Other useful commands are 'conda update -n base -c defaults conda' and
'conda update --all'. Run them after installation of new modules to update your environment path.

This scenario happens when there are usually different dependencies on your OS system.
Instructions scenario was tested on different version of Windows 10 OS (Lenovo Y50-70 NVIDIA GTX 960M)
##############


##############
If any other problems, or bugs during runtime, please contact author or institution in the app section 'About'.
